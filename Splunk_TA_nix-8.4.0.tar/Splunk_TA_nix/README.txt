Splunk Add-on for Unix and Linux
Copyright (C) 2021 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/UnixAddOn/latest
